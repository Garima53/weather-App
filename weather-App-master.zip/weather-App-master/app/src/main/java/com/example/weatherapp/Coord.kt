package com.example.weatherapp

data class Coord(
    val lat: Double,
    val lon: Double
)