Developed a weather app using the OpenWeatherMap API, featuring
a sleek user interface with a splash screen for enhanced user experience
in Kotlin language
